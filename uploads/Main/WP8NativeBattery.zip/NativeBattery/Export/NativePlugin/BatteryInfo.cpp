﻿#include "pch.h"
#include "BatteryInfo.h"

using namespace NativePlugin;
using namespace Platform;
using namespace Windows::Foundation;
using namespace Windows::Phone::Devices::Power;

BatteryInfo::BatteryInfo()
{
	m_Battery = Battery::GetDefault();
	m_Battery->RemainingChargePercentChanged += ref new EventHandler<Object^>(this, &BatteryInfo::OnRemainingChargePercentChanged);
}

int BatteryInfo::GetRemainingCharge()
{
	return m_Battery->RemainingChargePercent;
}

void BatteryInfo::OnRemainingChargePercentChanged(Object^ sender, Object^ args)
{
	auto const charge = GetRemainingCharge();
	RemainingChargeChanged(charge);
}
