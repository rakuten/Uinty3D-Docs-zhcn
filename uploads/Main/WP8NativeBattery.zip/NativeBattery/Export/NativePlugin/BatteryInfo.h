﻿#pragma once

namespace NativePlugin
{
	public delegate void RemainingChargeChangedCallback(int charge);

    public ref class BatteryInfo sealed
    {
	public:
		event RemainingChargeChangedCallback^ RemainingChargeChanged;

	private:
		Windows::Phone::Devices::Power::Battery^ m_Battery;

	public:
		BatteryInfo();
		int GetRemainingCharge();

	private:
		void OnRemainingChargePercentChanged(Platform::Object^ sender, Platform::Object^ args);
    };
}
