NativeBattery is an example project that shows how to invoke native code from Unity on Windows Phone.

It has been tested with 04-19 build.

To run example project:
- Open Export\NativeBattery.sln solution with Visual Studio 2012
- Connect your phone to PC and make sure device is unlocked
- Build and run example project

NativeBattery app displays remaining battery charge reported by native plugin.

Delegates must be used to invoke native code. Create C++ Windows Phone Runtime Component project (native plugin) and reference it from exported Visual Studio project. Expose public delegate from Unity script and initialize it in Visual Studio project (after Unity has been loaded). Now whenever this delegate is invoked from Unity side native code gets executed from your plugin. Please note that Unity runs on its own thread and proper synchronization must be implemented to prevent race conditions.

Native debugger must be selected to debug C++ code.
